local debugEnabled = Config.Debug

local function dprint(message)
    if debugEnabled then
        print(('^5[MWD SERVER]^7 %s'):format(message))
    end
end

local function weaponName(hash)
    return Config.HashNames[hash] or ('UNKNOWN_%s'):format(hash)
end

local function safeJson(value)
    local ok, encoded = pcall(json.encode, value)

    if ok then
        return encoded
    end

    return '<json encode failed>'
end

AddEventHandler('onResourceStart', function(resourceName)
    if resourceName ~= GetCurrentResourceName() then
        return
    end

    print(('^2[MWD SERVER]^7 started resource=%s debug=%s'):format(
        resourceName,
        tostring(debugEnabled)
    ))

    print('^2[MWD SERVER]^7 IMPORTANT: weaponDamageEvent requires networked damage/OneSync.')
end)

RegisterNetEvent('majestic_weapon_damage:debugHello', function()
    dprint(('client hello source=%s name=%s'):format(
        tostring(source),
        GetPlayerName(source) or 'unknown'
    ))
end)

RegisterNetEvent('majestic_weapon_damage:setDebugState', function(state)
    debugEnabled = state == true
    print(('^5[MWD SERVER]^7 debug changed by source=%s to %s'):format(
        tostring(source),
        tostring(debugEnabled)
    ))
end)

RegisterNetEvent('majestic_weapon_damage:status', function(selectedWeapon)
    dprint(('STATUS source=%s name=%s selected=%s(%s) configuredDamage=%s'):format(
        tostring(source),
        GetPlayerName(source) or 'unknown',
        weaponName(selectedWeapon),
        tostring(selectedWeapon),
        tostring(Config.Weapons[selectedWeapon])
    ))
end)

AddEventHandler('weaponDamageEvent', function(sender, data)
    local configuredDamage = Config.Weapons[data.weaponType]

    -- Always print the core event while debugging, even for unknown weapons.
    dprint(('weaponDamageEvent sender=%s name=%s weapon=%s(%s) configured=%s originalDamage=%s override=%s willKill=%s damageType=%s hitComponent=%s hitGlobalId=%s flags=%s full=%s'):format(
        tostring(sender),
        GetPlayerName(sender) or 'unknown',
        weaponName(data.weaponType),
        tostring(data.weaponType),
        tostring(configuredDamage),
        tostring(data.weaponDamage),
        tostring(data.overrideDefaultDamage),
        tostring(data.willKill),
        tostring(data.damageType),
        tostring(data.hitComponent),
        tostring(data.hitGlobalId),
        tostring(data.damageFlags),
        safeJson(data)
    ))

    if configuredDamage == nil then
        dprint('PASS: weapon is not configured')
        return
    end

    -- Equal damage for head and body: ignore hitComponent and force one value.
    data.overrideDefaultDamage = true
    data.weaponDamage = configuredDamage
    data.willKill = false

    dprint(('OVERRIDE: weapon=%s finalDamage=%s willKill=false'):format(
        weaponName(data.weaponType),
        tostring(configuredDamage)
    ))
end)
