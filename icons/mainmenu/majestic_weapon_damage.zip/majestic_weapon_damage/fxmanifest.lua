fx_version 'cerulean'
game 'gta5'

author 'Majestic'
description 'Server-authoritative weapon damage with client/server debugging'
version '1.0.0'

shared_script 'config.lua'
client_script 'client.lua'
server_script 'server.lua'
