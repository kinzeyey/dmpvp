Config = {}

-- Prints detailed logs in both F8 and the server console.
Config.Debug = true

-- Disable GTA critical/headshot instant-kill behavior.
Config.DisableCriticalHits = true

-- Only configured weapons are overridden.
-- Damage is the same for every body part, including the head.
Config.Weapons = {
    [`WEAPON_REVOLVER`]            = 51,
    [`WEAPON_REVOLVER_MK2`]        = 75,

    [`WEAPON_MARKSMANRIFLE_MK2`]   = 50,
    [`WEAPON_MARKSMANRIFLE`]       = 40,
    [`WEAPON_PRECISIONRIFLE`]      = 84,

    [`WEAPON_MICROSMG`]            = 8,
    [`WEAPON_SMG`]                 = 12,
    [`WEAPON_COMBATPDW`]           = 9,
    [`WEAPON_ASSAULTSMG`]          = 7,
    [`WEAPON_MACHINEPISTOL`]       = 8,

    [`WEAPON_COMBATMG`]            = 10,
    [`WEAPON_COMBATMG_MK2`]        = 15,
    [`WEAPON_MG`]                  = 15,

    [`WEAPON_ASSAULTRIFLE`]        = 18,
    [`WEAPON_COMPACTRIFLE`]        = 7,
    [`WEAPON_CARBINERIFLE`]        = 5,
    [`WEAPON_ADVANCEDRIFLE`]       = 10,
    [`WEAPON_SPECIALCARBINE`]      = 9,
    [`WEAPON_GUSENBERG`]           = 8,

    [`WEAPON_PUMPSHOTGUN`]         = 45,
    [`WEAPON_HEAVYSHOTGUN`]        = 35,
    [`WEAPON_SAWNOFFSHOTGUN`]      = 40,
    [`WEAPON_BULLPUPSHOTGUN`]      = 4,

    [`WEAPON_SNIPERRIFLE`]         = 65,
    [`WEAPON_HEAVYSNIPER`]         = 45,
    [`WEAPON_HEAVYSNIPER_MK2`]     = 65,

    [`WEAPON_COMBATPISTOL`]        = 10,
    [`WEAPON_VINTAGEPISTOL`]       = 12,
    [`WEAPON_PISTOL`]              = 7,
    [`WEAPON_DOUBLEACTION`]        = 28,
    [`WEAPON_HEAVYPISTOL`]         = 18,
    [`WEAPON_PISTOL50`]            = 9,
    [`WEAPON_SNSPISTOL`]           = 9,

    -- Explosives are not reliably converted to exact per-hit damage here.
    -- Keep RPG absent unless you only want to inspect its debug events.
}

Config.HashNames = {
    [`WEAPON_REVOLVER`] = 'WEAPON_REVOLVER',
    [`WEAPON_REVOLVER_MK2`] = 'WEAPON_REVOLVER_MK2',
    [`WEAPON_MARKSMANRIFLE_MK2`] = 'WEAPON_MARKSMANRIFLE_MK2',
    [`WEAPON_MARKSMANRIFLE`] = 'WEAPON_MARKSMANRIFLE',
    [`WEAPON_PRECISIONRIFLE`] = 'WEAPON_PRECISIONRIFLE',
    [`WEAPON_MICROSMG`] = 'WEAPON_MICROSMG',
    [`WEAPON_SMG`] = 'WEAPON_SMG',
    [`WEAPON_COMBATPDW`] = 'WEAPON_COMBATPDW',
    [`WEAPON_ASSAULTSMG`] = 'WEAPON_ASSAULTSMG',
    [`WEAPON_MACHINEPISTOL`] = 'WEAPON_MACHINEPISTOL',
    [`WEAPON_COMBATMG`] = 'WEAPON_COMBATMG',
    [`WEAPON_COMBATMG_MK2`] = 'WEAPON_COMBATMG_MK2',
    [`WEAPON_MG`] = 'WEAPON_MG',
    [`WEAPON_ASSAULTRIFLE`] = 'WEAPON_ASSAULTRIFLE',
    [`WEAPON_COMPACTRIFLE`] = 'WEAPON_COMPACTRIFLE',
    [`WEAPON_CARBINERIFLE`] = 'WEAPON_CARBINERIFLE',
    [`WEAPON_ADVANCEDRIFLE`] = 'WEAPON_ADVANCEDRIFLE',
    [`WEAPON_SPECIALCARBINE`] = 'WEAPON_SPECIALCARBINE',
    [`WEAPON_GUSENBERG`] = 'WEAPON_GUSENBERG',
    [`WEAPON_PUMPSHOTGUN`] = 'WEAPON_PUMPSHOTGUN',
    [`WEAPON_HEAVYSHOTGUN`] = 'WEAPON_HEAVYSHOTGUN',
    [`WEAPON_SAWNOFFSHOTGUN`] = 'WEAPON_SAWNOFFSHOTGUN',
    [`WEAPON_BULLPUPSHOTGUN`] = 'WEAPON_BULLPUPSHOTGUN',
    [`WEAPON_SNIPERRIFLE`] = 'WEAPON_SNIPERRIFLE',
    [`WEAPON_HEAVYSNIPER`] = 'WEAPON_HEAVYSNIPER',
    [`WEAPON_HEAVYSNIPER_MK2`] = 'WEAPON_HEAVYSNIPER_MK2',
    [`WEAPON_COMBATPISTOL`] = 'WEAPON_COMBATPISTOL',
    [`WEAPON_VINTAGEPISTOL`] = 'WEAPON_VINTAGEPISTOL',
    [`WEAPON_PISTOL`] = 'WEAPON_PISTOL',
    [`WEAPON_DOUBLEACTION`] = 'WEAPON_DOUBLEACTION',
    [`WEAPON_HEAVYPISTOL`] = 'WEAPON_HEAVYPISTOL',
    [`WEAPON_PISTOL50`] = 'WEAPON_PISTOL50',
    [`WEAPON_SNSPISTOL`] = 'WEAPON_SNSPISTOL',
}
