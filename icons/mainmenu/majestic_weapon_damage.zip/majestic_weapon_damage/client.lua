local debugEnabled = Config.Debug

local function dprint(message)
    if debugEnabled then
        print(('^3[MWD CLIENT]^7 %s'):format(message))
    end
end

local function weaponName(hash)
    return Config.HashNames[hash] or ('UNKNOWN_%s'):format(hash)
end

local function applyCriticalHitSetting()
    local ped = PlayerPedId()

    if ped ~= 0 and DoesEntityExist(ped) then
        SetPedSuffersCriticalHits(ped, not Config.DisableCriticalHits)

        dprint(('critical hits disabled=%s ped=%s'):format(
            tostring(Config.DisableCriticalHits),
            tostring(ped)
        ))
    end
end

local function configuredWeaponCount()
    local count = 0
    for _ in pairs(Config.Weapons) do
        count = count + 1
    end
    return count
end

CreateThread(function()
    Wait(1000)
    dprint(('resource started; configured weapons=%s'):format(
        tostring(configuredWeaponCount())
    ))

    while true do
        applyCriticalHitSetting()
        Wait(1000)
    end
end)

AddEventHandler('playerSpawned', function()
    Wait(500)
    applyCriticalHitSetting()
    dprint('playerSpawned received')
end)

AddEventHandler('onClientResourceStart', function(resourceName)
    if resourceName ~= GetCurrentResourceName() then
        return
    end

    dprint(('onClientResourceStart: %s'):format(resourceName))
    TriggerServerEvent('majestic_weapon_damage:debugHello')
end)

-- Official local client damage event.
AddEventHandler('entityDamaged', function(victim, culprit, weapon, baseDamage)
    if not debugEnabled then
        return
    end

    local victimIsMe = victim == PlayerPedId()
    local culpritPlayer = -1

    if culprit ~= 0 and DoesEntityExist(culprit) and IsEntityAPed(culprit) then
        culpritPlayer = NetworkGetPlayerIndexFromPed(culprit)
    end

    dprint(('entityDamaged victim=%s victimIsMe=%s culprit=%s culpritPlayer=%s weapon=%s(%s) baseDamage=%s health=%s armour=%s'):format(
        tostring(victim),
        tostring(victimIsMe),
        tostring(culprit),
        tostring(culpritPlayer),
        weaponName(weapon),
        tostring(weapon),
        tostring(baseDamage),
        tostring(GetEntityHealth(PlayerPedId())),
        tostring(GetPedArmour(PlayerPedId()))
    ))
end)

-- Low-level diagnostic event. Argument layout can differ between game builds,
-- so the complete array is printed rather than guessed.
AddEventHandler('gameEventTriggered', function(name, args)
    if not debugEnabled or name ~= 'CEventNetworkEntityDamage' then
        return
    end

    dprint(('CEventNetworkEntityDamage args=%s'):format(json.encode(args)))
end)

RegisterCommand('mwddebug', function()
    debugEnabled = not debugEnabled
    print(('^3[MWD CLIENT]^7 debug=%s'):format(tostring(debugEnabled)))
    TriggerServerEvent('majestic_weapon_damage:setDebugState', debugEnabled)
end, false)

RegisterCommand('mwdstatus', function()
    local ped = PlayerPedId()
    local selectedWeapon = GetSelectedPedWeapon(ped)

    dprint(('STATUS ped=%s health=%s armour=%s selected=%s(%s) configuredDamage=%s criticalDisabled=%s'):format(
        tostring(ped),
        tostring(GetEntityHealth(ped)),
        tostring(GetPedArmour(ped)),
        weaponName(selectedWeapon),
        tostring(selectedWeapon),
        tostring(Config.Weapons[selectedWeapon]),
        tostring(Config.DisableCriticalHits)
    ))

    TriggerServerEvent('majestic_weapon_damage:status', selectedWeapon)
end, false)
