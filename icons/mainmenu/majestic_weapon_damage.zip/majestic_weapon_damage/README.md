# Majestic Weapon Damage

## Installation

1. Copy the folder `majestic_weapon_damage` into your resources directory.
2. Put this near the bottom of `server.cfg`:

   ensure majestic_weapon_damage

3. Ensure OneSync is enabled.
4. Fully restart the server.
5. Join with two players and test player-vs-player damage.

## Debugging

Client F8 commands:

- `mwdstatus` — prints current weapon, hash, health, armour, and configured damage.
- `mwddebug` — toggles debug printing.

Expected startup logs:

Client F8:
- `[MWD CLIENT] onClientResourceStart`
- `[MWD CLIENT] critical hits disabled=true`

Server console:
- `[MWD SERVER] started`
- `[MWD SERVER] client hello`

Expected shot logs:

Victim/shooter F8:
- `[MWD CLIENT] entityDamaged ...`
- `[MWD CLIENT] CEventNetworkEntityDamage ...`

Server:
- `[MWD SERVER] weaponDamageEvent ...`
- `[MWD SERVER] OVERRIDE ...`

If client damage appears but the server never prints `weaponDamageEvent`, the
server-side override path is not receiving the network event. Check OneSync,
test with two different players, and temporarily disable other damage or
anti-cheat resources.

## Notes

- Head and body use the same configured value because hitComponent is ignored.
- Critical GTA headshots are disabled locally on every client.
- Armour and GTA damage processing can affect observed health loss.
- Shotguns may generate behavior that is not equivalent to one simple bullet.
- RPG/explosion damage uses different mechanics and is not included.
